package top.maple_bamboo_team.mbtfly.util;

import net.minecraft.class_243;
import net.minecraft.class_746;

public class AimingUtils {

    public static double getYaw(class_243 playerPos, class_243 targetPos) {
        class_243 direction = targetPos.method_1020(playerPos);
        return Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0;
    }

    public static double getPitch(class_243 playerPos, class_243 targetPos) {
        class_243 direction = targetPos.method_1020(playerPos);
        return -Math.toDegrees(Math.asin(direction.field_1351 / direction.method_1033()));
    }

    public static void aimAt(class_746 player, class_243 target) {
        class_243 eyePos = player.method_33571();
        class_243 direction = target.method_1020(eyePos).method_1029();
        double yaw = Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90.0;
        double pitch = -Math.toDegrees(Math.asin(direction.field_1351));
        player.method_36456((float) yaw);
        player.method_36457((float) pitch);
    }
}